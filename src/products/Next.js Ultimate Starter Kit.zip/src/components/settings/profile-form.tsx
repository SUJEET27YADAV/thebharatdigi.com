'use client';

import { type FormEvent, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { profileUpdateSchema } from '@/lib/validators';

interface ProfileFormProps {
  name: string;
  bio?: string;
  avatarUrl?: string;
}

export function ProfileForm({ name: initialName, bio: initialBio, avatarUrl: initialAvatarUrl }: ProfileFormProps) {
  const [name, setName] = useState(initialName);
  const [bio, setBio] = useState(initialBio ?? '');
  const [avatarUrl, setAvatarUrl] = useState(initialAvatarUrl ?? '');
  const [status, setStatus] = useState<string | null>(null);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus(null);

    try {
      profileUpdateSchema.parse({ name, bio, avatarUrl });
      const response = await fetch('/api/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, bio, avatarUrl })
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || 'Unable to update profile');
      }

      setStatus('Profile updated successfully.');
    } catch (error) {
      if (error instanceof Error) {
        setStatus(error.message);
      } else {
        setStatus('An unknown error occurred.');
      }
    }
  }

  return (
    <form className="space-y-6" onSubmit={handleSubmit}>
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <Label htmlFor="name">Full name</Label>
          <Input id="name" value={name} onChange={(event) => setName(event.target.value)} placeholder="Alex Example" />
        </div>
        <div>
          <Label htmlFor="avatarUrl">Avatar URL</Label>
          <Input id="avatarUrl" value={avatarUrl} onChange={(event) => setAvatarUrl(event.target.value)} placeholder="https://..." />
        </div>
      </div>

      <div>
        <Label htmlFor="bio">Bio</Label>
        <textarea
          id="bio"
          value={bio}
          onChange={(event) => setBio(event.target.value)}
          className="min-h-[140px] w-full rounded-md border border-slate-700 bg-slate-900 px-3 py-2 text-sm text-slate-100 shadow-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
          placeholder="Share your role and focus areas..."
        />
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-slate-400">Use this form to update the profile information shown on the dashboard.</p>
        <Button type="submit">Save settings</Button>
      </div>

      {status ? <p className="text-sm text-slate-300">{status}</p> : null}
    </form>
  );
}
