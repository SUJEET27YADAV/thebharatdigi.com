"use client";
import { Home, LayoutDashboard, Settings, Users, LogOut } from "lucide-react";
import { NavLink } from "@/components/ui/nav-link";
import { NavBtn } from "../ui/nav-btn";
import { signOut, useSession } from "next-auth/react";

interface SidebarProps {
  activeRoute: "/dashboard" | "/settings";
}

export function Sidebar({ activeRoute }: SidebarProps) {
  const { data: session } = useSession();
  const user = session?.user;
  return (
    <aside className="sm:w-72 shrink-0 space-y-6 border-r border-slate-800/70 bg-slate-950/80 p-1 sm:p-6">
      <div className="space-y-2">
        <p className="hidden sm:block text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">
          Workspace
        </p>
        <nav className="space-y-1">
          <NavLink href="/dashboard" active={activeRoute === "/dashboard"}>
            <LayoutDashboard className="h-4 w-4" />
            <span className="max-sm:hidden">Dashboard</span>
          </NavLink>
          <NavLink href="/settings" active={activeRoute === "/settings"}>
            <Settings className="h-4 w-4" />
            <span className="max-sm:hidden">Settings</span>
          </NavLink>
          <NavLink href="/" active={false}>
            <Home className="h-4 w-4" />
            <span className="max-sm:hidden">Home</span>
          </NavLink>
          {user ? (
            <NavBtn
              onClick={() => signOut({ callbackUrl: "/auth/login" })}
              active={false}
            >
              <LogOut className="h-4 w-4" />
              <span className="max-sm:hidden">Logout</span>
            </NavBtn>
          ) : (
            <NavLink href="/auth/login" active={false}>
              <Users className="h-4 w-4" />
              <span className="max-sm:hidden">Login</span>
            </NavLink>
          )}
        </nav>
      </div>
    </aside>
  );
}
