"use client";

import Link from "next/link";
import { signOut } from "next-auth/react";
import { LogOut, Settings, Sparkles } from "lucide-react";

interface NavbarProps {
  userName: string | null | undefined;
}

export function Navbar({ userName }: NavbarProps) {
  const handleSignOut = () => {
    signOut({ callbackUrl: "/auth/login" });
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-800/70 bg-slate-950/95 px-6 py-4 backdrop-blur-xl">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Link
            href="/"
            className="flex h-11 w-11 items-center justify-center rounded-2xl bg-primary/10 text-primary"
          >
            <Sparkles className="h-5 w-5" />
          </Link>
          {userName && (
            <div>
              <p className="text-sm font-medium text-slate-100">
                Welcome back,
              </p>
              <p className="text-base font-semibold text-white">{userName}</p>
            </div>
          )}
        </div>
        {userName && (
          <div className="flex items-center gap-2">
            <Link
              href="/settings"
              className="inline-flex items-center gap-2 rounded-xl border border-slate-800/80 bg-slate-900 px-3 py-2 text-sm text-slate-200 transition hover:border-slate-700 hover:bg-slate-800"
            >
              <Settings className="h-4 w-4" />
              <span className="max-sm:hidden">Settings</span>
            </Link>
            <button
              onClick={handleSignOut}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-800/80 bg-slate-900 px-3 py-2 text-sm text-slate-200 transition hover:border-slate-700 hover:bg-slate-800"
            >
              <LogOut className="h-4 w-4" />
              <span className="max-sm:hidden">Sign out</span>
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
