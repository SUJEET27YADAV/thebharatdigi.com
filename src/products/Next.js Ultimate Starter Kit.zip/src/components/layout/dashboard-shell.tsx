import { ReactNode } from "react";
import { Sidebar } from "@/components/layout/sidebar";

interface DashboardShellProps {
  children: ReactNode;
  activeRoute: "/dashboard" | "/settings";
}

export function DashboardShell({ children, activeRoute }: DashboardShellProps) {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <div className="mx-auto flex max-w-7xl gap-6 px-2 sm:px-4 py-8 sm:px-6 lg:px-8">
        <Sidebar activeRoute={activeRoute} />
        <main className="min-w-0 flex-1 rounded-3xl border border-slate-800/70 bg-slate-900/80 p-6 shadow-xl shadow-slate-950/20">
          {children}
        </main>
      </div>
    </div>
  );
}
