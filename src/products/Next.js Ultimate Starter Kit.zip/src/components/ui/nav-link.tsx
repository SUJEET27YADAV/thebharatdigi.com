import Link from "next/link";
import { cn } from "@/lib/utils";
import type { AnchorHTMLAttributes } from "react";

interface NavLinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  href: string;
  active?: boolean;
}

export function NavLink({
  href,
  active = false,
  className,
  children,
  ...props
}: NavLinkProps) {
  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 rounded-xl p-2 sm:px-3 sm:py-2 text-sm font-medium transition-colors",
        active
          ? "bg-slate-800 text-white"
          : "text-slate-300 hover:bg-slate-900 hover:text-white",
        className,
      )}
      {...props}
    >
      {children}
    </Link>
  );
}
