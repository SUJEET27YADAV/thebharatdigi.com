import { cn } from "@/lib/utils";
import type { ButtonHTMLAttributes } from "react";

interface NavBtnProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  onClick: () => void;
  active?: boolean;
}

export function NavBtn({
  onClick,
  active = false,
  className,
  children,
  ...props
}: NavBtnProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 rounded-xl p-2 sm:px-3 sm:py-2 text-sm font-medium transition-colors",
        active
          ? "bg-slate-800 text-white"
          : "text-slate-300 hover:bg-slate-900 hover:text-white",
        className,
      )}
      {...props}
    >
      {children}
    </button>
  );
}
