import * as React from 'react';
import { cn } from '@/lib/utils';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {}

export function Card({ className, ...props }: CardProps) {
  return (
    <div
      className={cn(
        'rounded-2xl border border-slate-800/70 bg-slate-950/90 p-6 shadow-lg shadow-slate-950/10',
        className
      )}
      {...props}
    />
  );
}
