import { z } from 'zod';

export const usersSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  password: z.string().min(6).max(255)
});

export const profileUpdateSchema = z.object({
  name: z.string().min(2).max(100),
  bio: z.string().max(280).optional(),
  avatarUrl: z.string().url().optional()
});

export type ProfileUpdateSchema = z.infer<typeof profileUpdateSchema>;
