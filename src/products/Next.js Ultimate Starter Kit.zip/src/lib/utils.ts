import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Merge Tailwind CSS class names into a canonical string.
 * @param inputs - Class name fragments.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
