import type { Metadata } from "next";
import "@/app/globals.css";
import { Providers } from "@/components/providers";
import ClientLayout from "./clientLayout";

export const metadata: Metadata = {
  title: "StarterKit",
  description: "A modern SaaS starter kit with Next.js, Drizzle, and Tailwind.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <Providers>
          <ClientLayout>{children}</ClientLayout>
        </Providers>
      </body>
    </html>
  );
}
