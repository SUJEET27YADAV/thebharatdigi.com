import { DashboardShell } from '@/components/layout/dashboard-shell';
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { Card } from '@/components/ui/card';
import { db } from '@/lib/db';
import { profiles, users } from '@/db/schema';
import { authOptions } from '@/lib/auth';

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    redirect('/auth/login');
  }

  const usersCount = await db.select().from(users);
  const profilesCount = await db.select().from(profiles);

  return (
    <DashboardShell currentUserName={session.user.name || 'User'} activeRoute="/dashboard">
      <div className="space-y-8">
        <section className="space-y-4">
          <h1 className="text-3xl font-semibold text-white">Dashboard</h1>
          <p className="max-w-2xl text-slate-400">
            Manage your starter SaaS product and inspect the database preview for user and profile records.
          </p>
        </section>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <p className="text-sm text-slate-500">Total users</p>
            <p className="mt-4 text-4xl font-semibold text-white">{usersCount.length}</p>
          </Card>
          <Card>
            <p className="text-sm text-slate-500">Total profiles</p>
            <p className="mt-4 text-4xl font-semibold text-white">{profilesCount.length}</p>
          </Card>
        </div>
      </div>
    </DashboardShell>
  );
}
