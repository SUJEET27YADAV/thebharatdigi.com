'use client';

import { useEffect } from 'react';
import Link from 'next/link';

interface ErrorProps {
  error: Error;
  reset: () => void;
}

export default function GlobalError({ error, reset }: ErrorProps) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-950 px-6 py-16 text-slate-100">
      <div className="max-w-xl rounded-3xl border border-slate-800/80 bg-slate-900/95 p-10 text-center shadow-2xl shadow-slate-950/20">
        <h1 className="text-3xl font-semibold text-white">Something went wrong</h1>
        <p className="mt-4 text-slate-400">An unexpected error occurred. Please refresh the page or try again later.</p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
          <button className="rounded-xl bg-primary px-4 py-3 text-sm font-medium text-white transition hover:bg-primary/90" onClick={() => reset()}>
            Try again
          </button>
          <Link href="/" className="rounded-xl border border-slate-700 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-slate-800">
            Return home
          </Link>
        </div>
      </div>
    </main>
  );
}
