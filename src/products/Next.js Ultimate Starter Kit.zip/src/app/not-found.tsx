import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-950 px-6 py-16 text-slate-100">
      <div className="max-w-xl rounded-3xl border border-slate-800/80 bg-slate-900/95 p-10 text-center shadow-2xl shadow-slate-950/20">
        <h1 className="text-4xl font-semibold text-white">404</h1>
        <p className="mt-4 text-slate-400">The page you were looking for could not be found.</p>
        <Link href="/" className="mt-8 inline-flex rounded-xl border border-slate-700 px-4 py-3 text-sm font-medium text-slate-100 transition hover:bg-slate-800">
          Return to home
        </Link>
      </div>
    </main>
  );
}
