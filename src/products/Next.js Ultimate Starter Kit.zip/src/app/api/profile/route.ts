import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { eq } from 'drizzle-orm';
import { db } from '@/lib/db';
import { profiles, users } from '@/db/schema';
import { profileUpdateSchema } from '@/lib/validators';
import { authOptions } from '@/lib/auth';

export async function POST(request: Request) {
  const session = await getServerSession(authOptions);

  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const body = await request.json();
  const parsed = profileUpdateSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ error: 'Invalid profile values.' }, { status: 400 });
  }

  await db.update(users).set({ name: parsed.data.name }).where(eq(users.id, parseInt(session.user.id)));

  const existingProfile = await db.select().from(profiles).where(eq(profiles.userId, parseInt(session.user.id))).limit(1);

  if (existingProfile.length > 0) {
    await db.update(profiles).set({
      bio: parsed.data.bio ?? null,
      avatarUrl: parsed.data.avatarUrl ?? null
    }).where(eq(profiles.id, existingProfile[0].id));
  } else {
    await db.insert(profiles).values({
      userId: parseInt(session.user.id),
      bio: parsed.data.bio ?? null,
      avatarUrl: parsed.data.avatarUrl ?? null
    });
  }

  return NextResponse.json({ ok: true });
}
