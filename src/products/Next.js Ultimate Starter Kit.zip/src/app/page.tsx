import Link from "next/link";
import { ArrowRight, ShieldCheck, Sparkles } from "lucide-react";
import { Card } from "@/components/ui/card";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export default async function HomePage() {
  const session = await getServerSession(authOptions);
  const user = session?.user;
  return (
    <main className="min-h-screen bg-slate-95 px-6 py-16 text-slate-100 sm:px-10">
      <div className="mx-auto flex max-w-6xl flex-col gap-10 lg:flex-row lg:items-center lg:justify-between">
        <section className="max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-3 rounded-full border border-slate-800/80 bg-slate-900/80 px-4 py-2 text-sm text-slate-200">
            <Sparkles className="h-4 w-4 text-primary" />
            StarterKit — build SaaS faster with a polished starter.
          </div>
          <div className="space-y-4">
            <h1 className="text-4xl font-semibold tracking-tight text-white sm:text-5xl">
              SaaS starter architecture for professional teams.
            </h1>
            <p className="max-w-2xl text-lg leading-8 text-slate-300">
              A clean, extensible Next.js template with PostgreSQL, Drizzle ORM,
              and an authentication flow with Next-Auth package.
            </p>
          </div>
          <div className="flex flex-wrap gap-4">
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 rounded-xl bg-blue-500 px-5 py-3 text-sm font-medium text-white transition hover:bg-blue-500/90"
            >
              Launch dashboard <ArrowRight className="h-4 w-4" />
            </Link>
            {!user && (
              <Link
                href="/auth/login"
                className="inline-flex items-center justify-center rounded-xl border border-slate-800/90 px-4 py-3 text-sm text-slate-200 transition hover:bg-slate-900"
              >
                Sign in
              </Link>
            )}
          </div>
        </section>

        <Card className="border-slate-800/80 bg-slate-900/90 p-8 shadow-2xl shadow-slate-950/20">
          <p className="text-sm uppercase tracking-[0.3em] text-slate-500">
            Included features
          </p>
          <ul className="mt-6 space-y-4 text-slate-300">
            <li className="flex items-center gap-3">
              <ShieldCheck className="h-5 w-5 text-primary" />
              Modular auth and protected routes
            </li>
            <li className="flex items-center gap-3">
              <ShieldCheck className="h-5 w-5 text-primary" />
              Tailwind + shadcn-inspired page components
            </li>
            <li className="flex items-center gap-3">
              <ShieldCheck className="h-5 w-5 text-primary" />
              Drizzle database schema and migrations
            </li>
          </ul>
        </Card>
      </div>
    </main>
  );
}
