"use client";
import { Navbar } from "@/components/layout/navbar";
import { useSession } from "next-auth/react";

export default function ClientLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { data: session } = useSession();
  const userName = session?.user?.name;
  return (
    <>
      <Navbar userName={userName} />
      {children}
    </>
  );
}
