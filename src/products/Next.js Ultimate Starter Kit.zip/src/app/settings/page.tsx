import { Card } from '@/components/ui/card';
import { ProfileForm } from '@/components/settings/profile-form';
import { DashboardShell } from '@/components/layout/dashboard-shell';
import { getServerSession } from 'next-auth';
import { redirect } from 'next/navigation';
import { eq } from 'drizzle-orm';
import { db } from '@/lib/db';
import { profiles } from '@/db/schema';
import { authOptions } from '@/lib/auth';

export default async function SettingsPage() {
  const session = await getServerSession(authOptions);

  if (!session?.user) {
    redirect('/auth/login');
  }

  const profileRecord = await db.select().from(profiles).where(eq(profiles.userId, parseInt(session.user.id))).limit(1);
  const profile = profileRecord[0] ?? null;

  return (
    <DashboardShell currentUserName={session.user.name || 'User'} activeRoute="/settings">
      <div className="space-y-8">
        <section className="space-y-4">
          <h1 className="text-3xl font-semibold text-white">Settings</h1>
          <p className="max-w-2xl text-slate-400">
            Update your starter profile and keep your account settings in one place.
          </p>
        </section>

        <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
          <section className="space-y-6">
            <Card>
              <h2 className="text-xl font-semibold text-white">Profile details</h2>
              <p className="text-sm text-slate-400">Changes are saved to the profile API, demonstrating a settings workflow.</p>
            </Card>
            <ProfileForm name={session.user.name || ''} bio={profile?.bio ?? ''} avatarUrl={profile?.avatarUrl ?? ''} />
          </section>

          <Card className="space-y-4">
            <h2 className="text-lg font-semibold text-white">Account overview</h2>
            <div className="space-y-3 text-sm text-slate-300">
              <p>
                Email: <span className="font-medium text-white">{session.user.email}</span>
              </p>
              <p>
                Status: <span className="font-medium text-white">Active</span>
              </p>
            </div>
          </Card>
        </div>
      </div>
    </DashboardShell>
  );
}
