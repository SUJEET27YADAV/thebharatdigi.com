# StarterKit

A SaaS starter kit built with Next.js App Router, TypeScript, Tailwind CSS, Drizzle ORM, PostgreSQL, Next-Auth and Zod.

## Features

- Clean App Router project structure
- Modular database schema with `users` and `profiles`
- PostgreSQL connection via `postgres.js`
- Real auth flow with for protected routes using Next-Auth
- Responsive dashboard layout with navbar and sidebar
- Global error and not-found pages
- Tailwind + custom UI components

## Getting Started

1. Copy the environment example:

   ```bash
   cp .env.example .env
   ```

2. Install dependencies:

   ```bash
   npm install
   ```

3. Update `DATABASE_URL` in `.env` with your PostgreSQL credentials.

4. Generate or run migrations:

   ```bash
   npm drizzle:generate
   npm drizzle:migrate
   ```

   or

   ```bash
   npx drizzle-kit generate
   npx drizzle-kit migrate
   ```

5. Start the development server:

   ```bash
   npm run dev
   ```

6. Open http://localhost:3000 in your browser.

## Database

The schema is located in `src/db/schema.ts` and includes:

- `users`: core user account data
- `profiles`: one-to-one profile metadata linked to `users`

The Drizzle config is in `drizzle.config.ts` and uses `DATABASE_URL`.

## Authentication

This starter kit includes an auth layer in `src/lib/auth.ts`.

- `/dashboard` is protected and redirects to `/auth/login`
- `/auth/signup` allows signing up with a your name, email and password.
- `/auth/login` allows signing in with a your email and password.
- `/api/auth/signin` sets a secure session cookie

## Pages

- `/`: public landing page
- `/dashboard`: authenticated dashboard shell
- `/settings`: profile settings template
- `/auth/signup`: auth signup
- `/auth/login`: auth login

## Quality

- TypeScript strict mode enabled
- Global error boundary in `src/app/error.tsx`
- 404 fallback in `src/app/not-found.tsx`
- Tailwind configured with forms plugin
