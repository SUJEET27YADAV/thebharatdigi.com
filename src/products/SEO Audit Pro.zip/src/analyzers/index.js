import { metaTagsAnalyzer } from "./meta-tags.js";
import { performanceAnalyzer } from "./performance.js";
import { linksAnalyzer } from "./links.js";
import { contentAnalyzer } from "./content.js";
import { imagesAnalyzer } from "./images.js";
import { socialAnalyzer } from "./social.js";
import { securityAnalyzer } from "./security.js";
import { mobileAnalyzer } from "./mobile.js";

const analyzers = [
  metaTagsAnalyzer,
  performanceAnalyzer,
  linksAnalyzer,
  contentAnalyzer,
  imagesAnalyzer,
  socialAnalyzer,
  securityAnalyzer,
  mobileAnalyzer,
];

export async function runAllAnalyzers(pages, options = {}) {
  const scoresByCategory = {};
  const details = {};
  const recommendations = [];
  let totalIssues = 0;
  let criticalIssues = 0;
  let warnings = 0;
  let passed = 0;

  for (const analyzer of analyzers) {
    if (options.verbose) console.log(`  Running: ${analyzer.name}`);
    const result = await analyzer.analyze(pages);
    scoresByCategory[analyzer.name] = result.score;
    details[analyzer.name] = result;

    const critical = result.findings.filter((f) => f.severity === "critical").length;
    const warning = result.findings.filter((f) => f.severity === "warning").length;
    criticalIssues += critical;
    warnings += warning;
    totalIssues += result.findings.length;
    passed += result.passed;

    recommendations.push(
      ...result.findings.map((f) => ({
        category: analyzer.name,
        severity: f.severity,
        issue: f.issue,
        fix: f.fix,
        page: f.page,
      })),
    );
  }

  const overallScore = Math.round(
    Object.values(scoresByCategory).reduce((a, b) => a + b, 0) / Object.keys(scoresByCategory).length,
  );

  return {
    overallScore,
    scoresByCategory,
    details,
    recommendations,
    totalIssues,
    criticalIssues,
    warnings,
    passed,
  };
}
