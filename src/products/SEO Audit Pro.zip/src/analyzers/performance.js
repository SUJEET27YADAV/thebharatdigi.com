export const performanceAnalyzer = {
  name: "Performance & Core Web Vitals",
  async analyze(pages) {
    const findings = [];
    let passed = 0;
    let total = 0;

    for (const page of pages) {
      const { $, url, headers } = page;

      total++;
      const htmlLen = $.html().length;
      if (htmlLen > 200000) {
        findings.push({ page: url, issue: `Large HTML size: ${(htmlLen / 1024).toFixed(0)}KB`, severity: "warning", fix: "Reduce HTML size. Minify HTML, trim unnecessary whitespace, and move inline scripts to external files." });
      } else {
        passed++;
      }

      total++;
      const inlineStyles = $("style").length;
      if (inlineStyles > 0) {
        findings.push({ page: url, issue: `${inlineStyles} inline <style> block(s) found`, severity: "info", fix: "Move inline CSS to external stylesheets for better caching." });
      } else {
        passed++;
      }

      total++;
      const scriptCount = $("script").length;
      const externalScripts = $("script[src]").length;
      if (scriptCount > 20) {
        findings.push({ page: url, issue: `${scriptCount} script tags (${externalScripts} external)`, severity: "warning", fix: "Reduce number of scripts. Combine, defer, or lazy-load non-critical scripts." });
      } else {
        passed++;
      }

      total++;
      const cssCount = $('link[rel="stylesheet"]').length;
      if (cssCount > 5) {
        findings.push({ page: url, issue: `${cssCount} CSS files loaded`, severity: "warning", fix: "Combine CSS files to reduce HTTP requests." });
      } else {
        passed++;
      }

      total++;
      const hasDefer = $('script[defer]').length > 0;
      const hasAsync = $('script[async]').length > 0;
      if (!hasDefer && !hasAsync && scriptCount > 3) {
        findings.push({ page: url, issue: "Render-blocking scripts without defer/async", severity: "warning", fix: "Add defer or async to non-critical <script> tags." });
      } else {
        passed++;
      }

      total++;
      const compressionHeader = headers["content-encoding"];
      if (compressionHeader && (compressionHeader.includes("gzip") || compressionHeader.includes("br"))) {
        passed++;
      } else {
        findings.push({ page: url, issue: "No content compression detected", severity: "warning", fix: "Enable Gzip or Brotli compression on the server." });
      }

      total++;
      const cacheHeader = headers["cache-control"] || "";
      if (cacheHeader.includes("public") || cacheHeader.includes("max-age")) {
        passed++;
      } else {
        findings.push({ page: url, issue: "Weak or missing cache-control headers", severity: "warning", fix: "Set Cache-Control headers for static assets (e.g., max-age=31536000)." });
      }
    }

    const score = Math.round((passed / total) * 100);
    return { score, findings, passed, total };
  },
};
