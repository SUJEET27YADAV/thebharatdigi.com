export const socialAnalyzer = {
  name: "Social & Open Graph",
  async analyze(pages) {
    const findings = [];
    let passed = 0;
    let total = 0;

    for (const page of pages) {
      const { $, url } = page;

      total++;
      const ogTitle = $('meta[property="og:title"]').attr("content") || "";
      if (!ogTitle) {
        findings.push({ page: url, issue: "Missing og:title", severity: "warning", fix: 'Add <meta property="og:title" content="Page Title" /> for social sharing.' });
      } else {
        passed++;
      }

      total++;
      const ogDesc = $('meta[property="og:description"]').attr("content") || "";
      if (!ogDesc) {
        findings.push({ page: url, issue: "Missing og:description", severity: "warning", fix: 'Add <meta property="og:description" content="Description" /> for social sharing.' });
      } else {
        passed++;
      }

      total++;
      const ogImage = $('meta[property="og:image"]').attr("content") || "";
      if (!ogImage) {
        findings.push({ page: url, issue: "Missing og:image", severity: "warning", fix: 'Add <meta property="og:image" content="https://..." /> for rich social previews.' });
      } else {
        passed++;
      }

      total++;
      const ogUrl = $('meta[property="og:url"]').attr("content") || "";
      if (!ogUrl) {
        findings.push({ page: url, issue: "Missing og:url", severity: "info", fix: 'Add <meta property="og:url" content="..." /> to specify canonical social URL.' });
      } else {
        passed++;
      }

      total++;
      const ogType = $('meta[property="og:type"]').attr("content") || "";
      if (!ogType) {
        findings.push({ page: url, issue: "Missing og:type", severity: "info", fix: 'Add <meta property="og:type" content="website" />.' });
      } else {
        passed++;
      }

      total++;
      const twitterCard = $('meta[name="twitter:card"]').attr("content") || "";
      if (!twitterCard) {
        findings.push({ page: url, issue: "Missing twitter:card", severity: "warning", fix: 'Add <meta name="twitter:card" content="summary_large_image" />.' });
      } else {
        passed++;
      }

      total++;
      const twitterTitle = $('meta[name="twitter:title"]').attr("content") || "";
      if (!twitterTitle) {
        findings.push({ page: url, issue: "Missing twitter:title", severity: "info", fix: 'Add <meta name="twitter:title" content="..." />.' });
      } else {
        passed++;
      }

      total++;
      const twitterImage = $('meta[name="twitter:image"]').attr("content") || "";
      if (!twitterImage) {
        findings.push({ page: url, issue: "Missing twitter:image", severity: "info", fix: 'Add <meta name="twitter:image" content="..." />.' });
      } else {
        passed++;
      }

      total++;
      const ogLocale = $('meta[property="og:locale"]').attr("content") || "";
      if (!ogLocale) {
        findings.push({ page: url, issue: "Missing og:locale", severity: "info", fix: 'Add <meta property="og:locale" content="en_US" />.' });
      } else {
        passed++;
      }

      total++;
      const ogSiteName = $('meta[property="og:site_name"]').attr("content") || "";
      if (!ogSiteName) {
        findings.push({ page: url, issue: "Missing og:site_name", severity: "info", fix: 'Add <meta property="og:site_name" content="Site Name" />.' });
      } else {
        passed++;
      }

      const fbAppId = $('meta[property="fb:app_id"]').attr("content") || "";
      total++;
      if (!fbAppId) {
        // Not critical, optional
        passed++;
      } else {
        passed++;
      }
    }

    const score = Math.round((passed / total) * 100);
    return { score, findings, passed, total };
  },
};
