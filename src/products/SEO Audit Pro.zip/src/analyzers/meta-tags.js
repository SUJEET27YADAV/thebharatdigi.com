export const metaTagsAnalyzer = {
  name: "Meta Tags & Headings",
  async analyze(pages) {
    const findings = [];
    let passed = 0;
    let total = 0;

    for (const page of pages) {
      const { $, url } = page;

      total++;
      const title = $("title").text().trim();
      const titleLength = title.length;
      const hasTitle = title.length > 0;

      if (!hasTitle) {
        findings.push({ page: url, issue: "Missing <title> tag", severity: "critical", fix: "Add a unique <title> tag between 50-60 characters." });
      } else if (titleLength < 30 || titleLength > 60) {
        findings.push({ page: url, issue: `Title length: ${titleLength} characters (recommended: 50-60)`, severity: "warning", fix: "Optimize the title to be between 50-60 characters." });
      } else {
        passed++;
      }

      total++;
      const metaDesc = $('meta[name="description"]').attr("content") || "";
      const descLength = metaDesc.length;
      if (!metaDesc) {
        findings.push({ page: url, issue: "Missing meta description", severity: "critical", fix: "Add a unique meta description between 150-160 characters." });
      } else if (descLength < 120 || descLength > 160) {
        findings.push({ page: url, issue: `Meta description length: ${descLength} characters (recommended: 150-160)`, severity: "warning", fix: "Optimize the meta description to be between 150-160 characters." });
      } else {
        passed++;
      }

      total++;
      const h1Count = $("h1").length;
      if (h1Count === 0) {
        findings.push({ page: url, issue: "Missing <h1> tag", severity: "critical", fix: "Add exactly one <h1> tag containing the primary keyword." });
      } else if (h1Count > 1) {
        findings.push({ page: url, issue: `Multiple <h1> tags (${h1Count})`, severity: "warning", fix: "Use only one <h1> tag per page." });
      } else {
        passed++;
      }

      const h1Text = $("h1").first().text().trim();
      total++;
      if (h1Text && title && !title.toLowerCase().includes(h1Text.toLowerCase()) && !h1Text.toLowerCase().includes(title.toLowerCase())) {
        findings.push({ page: url, issue: "<h1> and <title> don't share core keywords", severity: "warning", fix: "Align the <h1> and <title> tags around the primary keyword." });
      } else {
        passed++;
      }

      const headings = [];
      for (let i = 1; i <= 6; i++) {
        $(`h${i}`).each((_, el) => headings.push({ tag: `h${i}`, text: $(el).text().trim() }));
      }
      const hasH2 = $("h2").length > 0;
      total++;
      if (!hasH2 && headings.length > 1) {
        findings.push({ page: url, issue: "Missing <h2> subheadings", severity: "warning", fix: "Add <h2> subheadings to structure content hierarchically." });
      } else {
        passed++;
      }

      let prevLevel = 0;
      let outlineValid = true;
      for (const h of headings) {
        const level = parseInt(h.tag[1]);
        if (level > prevLevel + 1 && prevLevel > 0) {
          outlineValid = false;
          break;
        }
        prevLevel = level;
      }
      total++;
      if (!outlineValid && headings.length > 0) {
        findings.push({ page: url, issue: "Heading hierarchy is skipped (e.g., h1 → h3 without h2)", severity: "warning", fix: "Ensure heading hierarchy follows a logical structure (h1 → h2 → h3)." });
      } else {
        passed++;
      }

      total++;
      const hasViewport = $('meta[name="viewport"]').length > 0;
      if (!hasViewport) {
        findings.push({ page: url, issue: "Missing viewport meta tag", severity: "critical", fix: 'Add <meta name="viewport" content="width=device-width, initial-scale=1">.' });
      } else {
        passed++;
      }

      total++;
      const hasCharset = $('meta[charset]').length > 0 || $('meta[http-equiv="Content-Type"]').length > 0;
      if (!hasCharset) {
        findings.push({ page: url, issue: "Missing character encoding declaration", severity: "warning", fix: 'Add <meta charset="UTF-8"> in the <head>.' });
      } else {
        passed++;
      }

      total++;
      const hasLang = $("html").attr("lang");
      if (!hasLang) {
        findings.push({ page: url, issue: "Missing lang attribute on <html>", severity: "warning", fix: 'Add lang="en" to the <html> tag.' });
      } else {
        passed++;
      }

      total++;
      const hasCanonical = $('link[rel="canonical"]').length > 0;
      if (!hasCanonical) {
        findings.push({ page: url, issue: "Missing canonical URL", severity: "warning", fix: 'Add <link rel="canonical" href="..." /> to prevent duplicate content issues.' });
      } else {
        passed++;
      }
    }

    const score = Math.round((passed / total) * 100);
    return { score, findings, passed, total };
  },
};
