export const imagesAnalyzer = {
  name: "Images & Media",
  async analyze(pages) {
    const findings = [];
    let passed = 0;
    let total = 0;

    for (const page of pages) {
      const { $, url } = page;

      const images = [];
      $("img").each((_, el) => {
        images.push({
          src: $(el).attr("src") || "",
          alt: $(el).attr("alt") || "",
          width: $(el).attr("width"),
          height: $(el).attr("height"),
          loading: $(el).attr("loading") || "",
        });
      });

      total++;
      if (images.length === 0) {
        findings.push({ page: url, issue: "No images found on page", severity: "info", fix: "Add relevant images to improve engagement and SEO." });
        passed++;
        continue;
      }

      const imagesWithoutAlt = images.filter((img) => !img.alt);
      total++;
      if (imagesWithoutAlt.length > 0) {
        findings.push({ page: url, issue: `${imagesWithoutAlt.length}/${images.length} images missing alt text`, severity: "critical", fix: "Add descriptive alt text to all images. Use keywords naturally where appropriate." });
      } else {
        passed++;
      }

      const imagesWithoutDimensions = images.filter((img) => !img.width || !img.height);
      total++;
      if (imagesWithoutDimensions.length > 0) {
        findings.push({ page: url, issue: `${imagesWithoutDimensions.length}/${images.length} images missing width/height attributes`, severity: "warning", fix: "Add width and height attributes to prevent Cumulative Layout Shift (CLS)." });
      } else {
        passed++;
      }

      const nonHeroImages = images.slice(1);
      total++;
      const lazyLoadMissing = nonHeroImages.filter((img) => !img.loading);
      if (lazyLoadMissing.length > 3) {
        findings.push({ page: url, issue: `${lazyLoadMissing.length} below-fold images not using lazy loading`, severity: "warning", fix: 'Add loading="lazy" to below-the-fold images to improve initial page load.' });
      } else {
        passed++;
      }

      const largeImages = [];
      for (const img of images) {
        if (img.src && (img.src.includes(".jpg") || img.src.includes(".png") || img.src.includes(".webp")) && !img.width && !img.height) {
          largeImages.push(img.src);
        }
      }
      total++;
      if (largeImages.length > 0) {
        findings.push({ page: url, issue: `${largeImages.length} image(s) may lack WebP/modern format`, severity: "info", fix: "Convert images to WebP/AVIF format and specify explicit dimensions." });
      } else {
        passed++;
      }

      total++;
      const nextGenFormats = images.filter((img) => img.src && (img.src.includes(".webp") || img.src.includes(".avif")));
      if (nextGenFormats.length < images.length * 0.5 && images.length > 0) {
        findings.push({ page: url, issue: `<50% of images use modern formats (WebP/AVIF)`, severity: "warning", fix: "Serve images in WebP or AVIF format for smaller file sizes." });
      } else {
        passed++;
      }
    }

    const score = Math.round((passed / total) * 100);
    return { score, findings, passed, total };
  },
};
