export const linksAnalyzer = {
  name: "Links & Indexing",
  async analyze(pages) {
    const findings = [];
    let passed = 0;
    let total = 0;

    for (const page of pages) {
      const { $, url } = page;

      const allInternalLinks = [];
      const allExternalLinks = [];
      $("a[href]").each((_, el) => {
        const href = $(el).attr("href");
        if (!href || href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("tel:")) return;
        try {
          const resolved = new URL(href, url);
          const base = new URL(url);
          if (resolved.hostname === base.hostname) {
            allInternalLinks.push(resolved.href);
          } else {
            allExternalLinks.push(resolved.href);
          }
        } catch {}
      });

      total++;
      if (allInternalLinks.length === 0) {
        findings.push({ page: url, issue: "No internal links found", severity: "warning", fix: "Add internal links to improve site navigation and link equity distribution." });
      } else {
        passed++;
      }

      const brokenLinks = [];
      for (const link of allInternalLinks.slice(0, 20)) {
        try {
          const resp = await fetch(link, { method: "HEAD", signal: AbortSignal.timeout(5000) });
          if (resp.status >= 400) {
            brokenLinks.push({ link, status: resp.status });
          }
        } catch {
          brokenLinks.push({ link, status: "error" });
        }
      }

      total++;
      if (brokenLinks.length > 0) {
        findings.push({ page: url, issue: `Found ${brokenLinks.length} broken internal link(s)`, severity: "critical", fix: `Fix or remove broken links: ${brokenLinks.map(b => b.link).join(", ")}` });
      } else {
        passed++;
      }

      const noFollowLinks = [];
      $("a[rel*='nofollow']").each((_, el) => {
        const href = $(el).attr("href");
        if (href) noFollowLinks.push(href);
      });

      total++;
      if (noFollowLinks.length > 5) {
        findings.push({ page: url, issue: `${noFollowLinks.length} nofollow links found — may indicate link quality issues`, severity: "info", fix: "Review nofollow links. Only use nofollow for sponsored or untrusted content." });
      } else {
        passed++;
      }

      total++;
      const externalNoFollow = [];
      for (const link of allExternalLinks.slice(0, 10)) {
        const $a = $(`a[href="${link.replace(/"/g, '\\"')}"]`);
        const rel = $a.attr("rel") || "";
        if (!rel.includes("nofollow") && !rel.includes("sponsored") && !rel.includes("ugc")) {
          externalNoFollow.push(link);
        }
      }
      if (externalNoFollow.length > 0) {
        findings.push({ page: url, issue: `${externalNoFollow.length} external link(s) missing rel="nofollow" or rel="sponsored"`, severity: "info", fix: 'Add rel="nofollow" or rel="sponsored" to external links.' });
      } else {
        passed++;
      }

      total++;
      const hasRobotsMeta = $('meta[name="robots"]').length > 0 || $('meta[name="googlebot"]').length > 0;
      if (hasRobotsMeta) {
        passed++;
      } else {
        findings.push({ page: url, issue: "Missing robots meta tag", severity: "info", fix: 'Add <meta name="robots" content="index, follow"> to control crawling behavior.' });
      }

      total++;
      const hasNoindex = $('meta[name="robots"][content*="noindex"]').length > 0;
      if (hasNoindex) {
        findings.push({ page: url, issue: "Page has noindex directive", severity: "critical", fix: "Remove noindex if this page should appear in search results." });
      }

      total++;
      const imagesWithoutAlt = [];
      $("img:not([alt])").each((_, el) => {
        const src = $(el).attr("src");
        if (src) imagesWithoutAlt.push(src);
      });
      if (imagesWithoutAlt.length > 0) {
        findings.push({ page: url, issue: `${imagesWithoutAlt.length} image(s) without alt text affect link equity`, severity: "warning", fix: "Add descriptive alt text to all images." });
      } else {
        passed++;
      }
    }

    const score = Math.round((passed / total) * 100);
    return { score, findings, passed, total };
  },
};
