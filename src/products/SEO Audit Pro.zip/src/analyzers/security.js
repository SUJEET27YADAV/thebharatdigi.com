export const securityAnalyzer = {
  name: "Security & HTTPS",
  async analyze(pages) {
    const findings = [];
    let passed = 0;
    let total = 0;

    for (const page of pages) {
      const { $, url, headers } = page;

      total++;
      if (url.startsWith("https://")) {
        passed++;
      } else {
        findings.push({ page: url, issue: "Page is not served over HTTPS", severity: "critical", fix: "Install an SSL certificate and redirect HTTP to HTTPS." });
      }

      total++;
      const hstsHeader = headers["strict-transport-security"];
      if (hstsHeader) {
        passed++;
      } else {
        findings.push({ page: url, issue: "Missing HSTS (Strict-Transport-Security) header", severity: "warning", fix: 'Add header: Strict-Transport-Security: max-age=31536000; includeSubDomains' });
      }

      total++;
      const contentTypeHeader = headers["x-content-type-options"];
      if (contentTypeHeader && contentTypeHeader.toLowerCase() === "nosniff") {
        passed++;
      } else {
        findings.push({ page: url, issue: "Missing X-Content-Type-Options: nosniff header", severity: "warning", fix: 'Add header: X-Content-Type-Options: nosniff' });
      }

      total++;
      const xssHeader = headers["x-xss-protection"];
      if (xssHeader) {
        passed++;
      } else {
        findings.push({ page: url, issue: "Missing X-XSS-Protection header", severity: "info", fix: 'Add header: X-XSS-Protection: 1; mode=block' });
      }

      total++;
      const frameHeader = headers["x-frame-options"];
      if (frameHeader) {
        passed++;
      } else {
        findings.push({ page: url, issue: "Missing X-Frame-Options header (clickjacking risk)", severity: "warning", fix: 'Add header: X-Frame-Options: SAMEORIGIN or DENY' });
      }

      total++;
      const cspHeader = headers["content-security-policy"];
      if (cspHeader) {
        passed++;
      } else {
        findings.push({ page: url, issue: "Missing Content-Security-Policy header", severity: "warning", fix: "Implement a Content-Security-Policy header to prevent XSS attacks." });
      }

      const mixedContent = [];
      $("img[src^='http://'], script[src^='http://'], link[href^='http://'], iframe[src^='http://'], video source[src^='http://'], audio source[src^='http://']").each((_, el) => {
        const src = $(el).attr("src") || $(el).attr("href");
        if (src && !src.startsWith("https://")) mixedContent.push(src);
      });

      total++;
      if (url.startsWith("https://") && mixedContent.length > 0) {
        findings.push({ page: url, issue: `${mixedContent.length} mixed content resource(s) loaded over HTTP`, severity: "critical", fix: `Update these resources to HTTPS: ${mixedContent.slice(0, 5).join(", ")}` });
      } else {
        passed++;
      }

      total++;
      const referrerHeader = headers["referrer-policy"];
      if (referrerHeader) {
        passed++;
      } else {
        findings.push({ page: url, issue: "Missing Referrer-Policy header", severity: "info", fix: 'Add header: Referrer-Policy: strict-origin-when-cross-origin' });
      }

      total++;
      const permissionsHeader = headers["permissions-policy"];
      if (permissionsHeader) {
        passed++;
      } else {
        findings.push({ page: url, issue: "Missing Permissions-Policy header", severity: "info", fix: "Add a Permissions-Policy header to control browser features." });
      }
    }

    const score = Math.round((passed / total) * 100);
    return { score, findings, passed, total };
  },
};
