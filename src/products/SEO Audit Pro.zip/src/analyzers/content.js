export const contentAnalyzer = {
  name: "Content & Keyword Analysis",
  async analyze(pages) {
    const findings = [];
    let passed = 0;
    let total = 0;

    for (const page of pages) {
      const { $, url } = page;

      $("script, style, noscript, svg, code, pre").remove();
      const bodyText = $("body").text().trim();
      const wordCount = bodyText.split(/\s+/).filter(Boolean).length;

      total++;
      if (wordCount < 300) {
        findings.push({ page: url, issue: `Low word count: ${wordCount} words (recommended: 300+)`, severity: "warning", fix: "Expand content to at least 300 words for better search engine ranking." });
      } else if (wordCount > 5000) {
        findings.push({ page: url, issue: `Very long content: ${wordCount} words`, severity: "info", fix: "Consider breaking long content into logical sections or multi-page series." });
      } else {
        passed++;
      }

      const wordFreq = {};
      const words = bodyText.toLowerCase().match(/\b[a-z]{3,}\b/g) || [];
      for (const w of words) {
        wordFreq[w] = (wordFreq[w] || 0) + 1;
      }
      const sortedWords = Object.entries(wordFreq).sort((a, b) => b[1] - a[1]);
      const topKeywords = sortedWords.slice(0, 10).map(([word, count]) => ({ word, count, density: ((count / words.length) * 100).toFixed(1) }));

      total++;
      if (topKeywords.length > 0 && parseFloat(topKeywords[0].density) > 5) {
        findings.push({ page: url, issue: `Possible keyword stuffing: "${topKeywords[0].word}" appears ${topKeywords[0].count} times (${topKeywords[0].density}%)`, severity: "warning", fix: "Reduce usage of top keywords. Maintain natural keyword density (1-3%)." });
      } else {
        passed++;
      }

      total++;
      const sentences = bodyText.split(/[.!?]+/).filter(Boolean);
      const avgSentenceLength = sentences.length > 0 ? Math.round(words.length / sentences.length) : 0;
      if (avgSentenceLength > 25) {
        findings.push({ page: url, issue: `High average sentence length: ${avgSentenceLength} words`, severity: "warning", fix: "Shorten sentences. Aim for 15-20 words per sentence for better readability." });
      } else {
        passed++;
      }

      total++;
      const paragraphs = $("p").length;
      if (paragraphs === 0 && wordCount > 0) {
        findings.push({ page: url, issue: "No <p> tags found", severity: "warning", fix: "Use semantic <p> tags for text content instead of <div> or <br>." });
      } else {
        passed++;
      }

      total++;
      const lists = $("ul, ol").length;
      if (wordCount > 500 && lists === 0) {
        findings.push({ page: url, issue: "No lists found in content-heavy page", severity: "info", fix: "Use bulleted or numbered lists to improve scannability and featured snippet chances." });
      } else {
        passed++;
      }

      total++;
      const boldCount = $("strong, b").length;
      if (boldCount === 0 && wordCount > 200) {
        findings.push({ page: url, issue: "No bold/strong emphasis in long content", severity: "info", fix: "Highlight key terms with <strong> to improve skimming and keyword prominence." });
      } else {
        passed++;
      }

      const title = $("title").text().toLowerCase();
      const h1 = $("h1").first().text().toLowerCase();
      const bodyLower = bodyText.toLowerCase();

      total++;
      const titleWords = title.split(/\s+/).filter(Boolean);
      const keywordInBody = titleWords.some(w => w.length > 3 && bodyLower.includes(w));
      if (!keywordInBody && titleWords.length > 0) {
        findings.push({ page: url, issue: "Title keywords not found in body content", severity: "warning", fix: "Ensure primary keywords from the title appear naturally in the body." });
      } else {
        passed++;
      }

      total++;
      if (h1 && !bodyLower.includes(h1)) {
        findings.push({ page: url, issue: "H1 text not found in body content", severity: "info", fix: "Ensure the H1 heading keyword appears in the body content." });
      } else {
        passed++;
      }
    }

    const score = Math.round((passed / total) * 100);
    return { score, findings, passed, total, topKeywords: pages[0] ? (await extractTopKeywords(pages[0].$)) : [] };
  },
};

async function extractTopKeywords($) {
  $("script, style, noscript, svg").remove();
  const text = $("body").text().toLowerCase();
  const words = text.match(/\b[a-z]{4,}\b/g) || [];
  const stopWords = new Set(["this", "that", "with", "from", "have", "been", "were", "they", "them", "their", "will", "would", "could", "should", "about", "which", "when", "where", "what", "there", "your", "into", "than", "then", "also", "just", "more", "some", "each", "other", "only", "over", "such"]);
  const freq = {};
  for (const w of words) {
    if (!stopWords.has(w)) freq[w] = (freq[w] || 0) + 1;
  }
  return Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 15).map(([word, count]) => ({ word, count }));
}
