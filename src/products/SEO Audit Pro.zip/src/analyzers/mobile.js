export const mobileAnalyzer = {
  name: "Mobile Responsiveness",
  async analyze(pages) {
    const findings = [];
    let passed = 0;
    let total = 0;

    for (const page of pages) {
      const { $, url } = page;

      total++;
      const viewport = $('meta[name="viewport"]').attr("content") || "";
      if (viewport.includes("width=device-width")) {
        passed++;
      } else {
        findings.push({ page: url, issue: "Viewport meta tag does not set width=device-width", severity: "critical", fix: 'Use <meta name="viewport" content="width=device-width, initial-scale=1">.' });
      }

      total++;
      const hasMediaQueries = hasStyleWithMediaQueries($);
      if (hasMediaQueries) {
        passed++;
      } else {
        findings.push({ page: url, issue: "No responsive CSS media queries detected", severity: "critical", fix: "Implement CSS media queries for mobile, tablet, and desktop breakpoints." });
      }

      const smallElements = [];
      $("a, button, input, select, textarea").each((_, el) => {
        const fontSize = $(el).css("font-size");
        if (fontSize) {
          const sizeVal = parseFloat(fontSize);
          if (sizeVal < 12 && sizeVal > 0) {
            smallElements.push($(el).prop("tagName").toLowerCase());
          }
        }
      });

      total++;
      if (smallElements.length > 0) {
        findings.push({ page: url, issue: `${smallElements.length} interactive element(s) with font-size < 12px`, severity: "warning", fix: "Ensure all interactive elements have minimum 16px font size (especially on mobile)." });
      } else {
        passed++;
      }

      $("[style]").each((_, el) => {
        const style = $(el).attr("style");
        if (style && style.includes("width:") && !style.includes("%") && !style.includes("vw") && !style.includes("auto")) {
          const widthMatch = style.match(/width:\s*(\d+)px/);
          if (widthMatch && parseInt(widthMatch[1]) > 375) {
            findings.push({ page: url, issue: `Fixed-width element (${widthMatch[1]}px) may overflow on mobile`, severity: "warning", fix: "Use relative units (%, vw, rem) instead of fixed px for widths." });
          }
        }
      });

      total++;
      const useZoom = $('meta[name="viewport"]').attr("content") || "";
      if (useZoom.includes("user-scalable=no") || useZoom.includes("maximum-scale=1")) {
        findings.push({ page: url, issue: "Pinch-zoom disabled (user-scalable=no or maximum-scale=1)", severity: "warning", fix: "Remove user-scalable=no and maximum-scale=1 to allow pinch-zoom." });
      } else {
        passed++;
      }

      total++;
      const fontSizes = [];
      $("p, h1, h2, h3, h4, h5, h6, li, span, a, button, input, label").each((_, el) => {
        const size = $(el).css("font-size");
        if (size) fontSizes.push(parseFloat(size));
      });
      const minFont = fontSizes.length > 0 ? Math.min(...fontSizes) : 16;
      if (fontSizes.length > 0 && minFont < 12) {
        findings.push({ page: url, issue: `Minimum font size is ${minFont}px (below 12px recommended minimum)`, severity: "warning", fix: "Set a minimum font size of 16px for body text on mobile." });
      } else {
        passed++;
      }

      const tapTargets = [];
      $("a, button, input[type='submit'], input[type='button']").each((_, el) => {
        const width = $(el).css("width") || $(el).attr("width");
        const height = $(el).css("height") || $(el).attr("height");
        if (width && height) {
          const w = parseFloat(width);
          const h = parseFloat(height);
          if ((w < 44 || h < 44) && w > 0 && h > 0) {
            tapTargets.push($(el).prop("tagName").toLowerCase());
          }
        }
      });

      total++;
      if (tapTargets.length > 3) {
        findings.push({ page: url, issue: `${tapTargets.length} tap targets smaller than 44x44px`, severity: "warning", fix: "Ensure all interactive elements are at least 44x44px for mobile touch targets." });
      } else {
        passed++;
      }

      total++;
      const overflowHidden = $("*").filter((_, el) => {
        const overflow = $(el).css("overflow");
        return overflow === "hidden" && $(el).parent().length > 0;
      }).length;
      if (overflowHidden > 10) {
        findings.push({ page: url, issue: "Multiple elements with overflow:hidden may clip content on mobile", severity: "info", fix: "Review overflow:hidden usage — use overflow:auto or scroll where appropriate." });
      } else {
        passed++;
      }
    }

    const score = Math.round((passed / total) * 100);
    return { score, findings, passed, total };
  },
};

function hasStyleWithMediaQueries($) {
  let found = false;
  $("style").each((_, el) => {
    const content = $(el).html() || "";
    if (/@media\s*(screen|only|all)?\s*(and\s*\(|{)/i.test(content)) {
      found = true;
    }
  });
  return found;
}
