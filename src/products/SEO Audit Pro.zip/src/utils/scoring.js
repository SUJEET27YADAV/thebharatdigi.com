export function calculateScore(passed, total) {
  if (total === 0) return 100;
  return Math.round((passed / total) * 100);
}

export function severityLabel(score) {
  if (score >= 90) return "excellent";
  if (score >= 70) return "good";
  if (score >= 50) return "needs-improvement";
  return "critical";
}

export function scoreToGrade(score) {
  if (score >= 90) return "A";
  if (score >= 80) return "B";
  if (score >= 70) return "C";
  if (score >= 60) return "D";
  return "F";
}
