import * as cheerio from "cheerio";
import https from "https";
import http from "http";

class Crawler {
  async fetchPage(pageUrl) {
    return new Promise((resolve, reject) => {
      const mod = pageUrl.startsWith("https") ? https : http;
      const req = mod.get(
        pageUrl,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (compatible; SEOAuditPro/1.0; +https://thebharatdigi.com)",
            Accept: "text/html,application/xhtml+xml",
          },
          timeout: 10000,
        },
        (res) => {
          let data = "";
          res.on("data", (chunk) => (data += chunk));
          res.on("end", () => {
            resolve({
              url: pageUrl,
              statusCode: res.statusCode,
              headers: res.headers,
              html: data,
              $: cheerio.load(data),
            });
          });
        },
      );
      req.on("error", reject);
      req.on("timeout", () => {
        req.destroy();
        reject(new Error(`Timeout fetching ${pageUrl}`));
      });
    });
  }

  extractInternalLinks($, baseUrl) {
    const links = new Set();
    $("a[href]").each((_, el) => {
      let href = $(el).attr("href");
      if (!href || href.startsWith("#") || href.startsWith("mailto:") || href.startsWith("tel:")) return;
      try {
        const resolved = new URL(href, baseUrl).href;
        const base = new URL(baseUrl);
        const resolvedUrl = new URL(resolved);
        if (resolvedUrl.hostname === base.hostname && !resolved.includes("#")) {
          links.add(resolved);
        }
      } catch {}
    });
    return [...links];
  }

  async crawl(startUrl, options = {}) {
    const { depth = 1, maxPages = 10, verbose = false } = options;
    const visited = new Set();
    const pages = [];
    const queue = [{ url: startUrl, d: 0 }];

    while (queue.length > 0 && pages.length < maxPages) {
      const item = queue.shift();
      if (visited.has(item.url) || item.d > depth) continue;
      visited.add(item.url);

      try {
        if (verbose) console.log(`  Fetching: ${item.url}`);
        const page = await this.fetchPage(item.url);
        pages.push(page);

        if (item.d < depth) {
          const internalLinks = this.extractInternalLinks(page.$, item.url);
          for (const link of internalLinks) {
            if (!visited.has(link)) {
              queue.push({ url: link, d: item.d + 1 });
            }
          }
        }
      } catch (err) {
        if (verbose) console.error(`  Failed: ${item.url} — ${err.message}`);
      }
    }

    return pages;
  }
}

export const crawler = new Crawler();
