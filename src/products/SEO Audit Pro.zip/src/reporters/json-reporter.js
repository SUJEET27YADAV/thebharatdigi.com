import fs from "fs-extra";
import path from "path";

export const JSONReporter = {
  async generate(report, outputDir) {
    const filePath = path.join(outputDir, "seo-audit-report.json");
    await fs.writeJson(filePath, report, { spaces: 2 });
    return filePath;
  },
};
