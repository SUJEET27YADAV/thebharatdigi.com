#!/usr/bin/env node

import { program } from "commander";
import { crawler } from "./src/crawler.js";
import { runAllAnalyzers } from "./src/analyzers/index.js";
import { JSONReporter } from "./src/reporters/json-reporter.js";
import { HTMLReporter } from "./src/reporters/html-reporter.js";
import { SkillReporter } from "./src/reporters/skill-reporter.js";
import path from "path";
import chalk from "chalk";
import fs from "fs-extra";
program
  .name("seo-audit-pro")
  .description(
    "SEO Audit Pro — Comprehensive SEO auditing tool with AI agent skill generation",
  )
  .version("1.0.0");

program
  .command("audit")
  .description("Run a full SEO audit on a website")
  .argument("<url>", "Website URL to audit (e.g. https://example.com)")
  .option("-o, --output <dir>", "Output directory for reports", "./reports")
  .option("-d, --depth <n>", "Crawl depth (default: 1, max: 3)", "1")
  .option("-m, --max-pages <n>", "Maximum pages to crawl (default: 10)", "10")
  .option(
    "-s, --sitemap <url>",
    "Sitemap URL (optional, crawls sitemap instead of auto-crawl)",
  )
  .option("--skip-html", "Skip HTML report generation")
  .option("--skip-json", "Skip JSON report generation")
  .option("--skip-skill", "Skip AI skill report generation")
  .option("--verbose", "Enable verbose logging")
  .action(async (url, options) => {
    console.log(chalk.bold.hex("#ac4bff")("\n  ⚡ SEO Audit Pro v1.0.0"));
    console.log(
      chalk.dim("  The Bharat Digital — Production-Grade SEO Auditing\n"),
    );

    const startTime = Date.now();
    const outputDir = path.resolve(options.output);
    const depth = Math.min(parseInt(options.depth) || 1, 3);
    const maxPages = Math.min(parseInt(options.maxPages) || 10, 50);
    const sitemapUrl = options.sitemap || null;

    await fs.ensureDir(outputDir);

    const validUrl = url.startsWith("http") ? url : `https://${url}`;

    const pages = await crawler.crawl(validUrl, {
      depth,
      maxPages,
      sitemapUrl,
      verbose: options.verbose,
    });

    if (pages.length === 0) {
      console.error(
        chalk.red("✖ No pages were crawled. Check the URL and try again."),
      );
      process.exit(1);
    }

    console.log(chalk.cyan(`  📄 Crawled ${pages.length} page(s)\n`));

    const results = await runAllAnalyzers(pages, { verbose: options.verbose });

    const report = {
      meta: {
        tool: "SEO Audit Pro",
        version: "1.0.0",
        timestamp: new Date().toISOString(),
        targetUrl: validUrl,
        pagesCrawled: pages.length,
        crawlDepth: depth,
        duration: Date.now() - startTime,
      },
      summary: {
        overallScore: results.overallScore,
        scoresByCategory: results.scoresByCategory,
        totalIssues: results.totalIssues,
        criticalIssues: results.criticalIssues,
        warnings: results.warnings,
        passed: results.passed,
      },
      details: results.details,
      recommendations: results.recommendations,
    };

    if (!options.skipJson) {
      await JSONReporter.generate(report, outputDir);
      console.log(
        chalk.green(`  ✓ JSON report: ${outputDir}\\seo-audit-report.json`),
      );
    }

    if (!options.skipHtml) {
      const htmlPath = await HTMLReporter.generate(report, outputDir);
      console.log(chalk.green(`  ✓ HTML report: ${htmlPath}`));
    }

    if (!options.skipSkill) {
      await SkillReporter.generate(report, validUrl, outputDir);
      console.log(chalk.green(`  ✓ AI Skill: ${outputDir}\\SKILL.md`));
    }

    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log(
      chalk.bold.hex("#ac4bff")(`\n  ✅ Audit complete in ${elapsed}s`),
    );
    console.log(
      chalk.dim(`  📊 Overall score: ${report.summary.overallScore}/100\n`),
    );
  });

program
  .command("quick")
  .description("Quick single-page SEO check")
  .argument("<url>", "Page URL to check")
  .action(async (url) => {
    const validUrl = url.startsWith("http") ? url : `https://${url}`;
    const pages = await crawler.crawl(validUrl, { depth: 0, maxPages: 1 });
    if (pages.length === 0) {
      console.error(chalk.red("✖ Could not fetch the page."));
      process.exit(1);
    }
    const results = await runAllAnalyzers(pages);
    console.log(chalk.bold("\n  ⚡ Quick SEO Check"));
    console.log(chalk.dim(`  Target: ${validUrl}\n`));
    for (const [category, score] of Object.entries(results.scoresByCategory)) {
      const color =
        score >= 80 ? chalk.green : score >= 50 ? chalk.yellow : chalk.red;
      console.log(`  ${color(`● ${category}: ${score}/100`)}`);
    }
    console.log(
      chalk.bold.hex("#ac4bff")(`\n  Overall: ${results.overallScore}/100\n`),
    );
  });

program.parse(process.argv);
