# SEO Audit Pro ⚡

**Production-grade SEO auditing tool with AI agent skill generation.**

Scan any website across 8 critical SEO dimensions, get a detailed report, and receive an AI-ready SKILL.md file that agents can use to implement fixes automatically.

## Features

- **8 Comprehensive SEO Checks:**
  - Meta Tags & Headings — Title, description, H1-H6 structure, canonical URLs
  - Performance & Core Web Vitals — HTML size, scripts, CSS, caching, compression
  - Links & Indexing — Internal/external links, broken links, robots, nofollow
  - Content & Keyword Analysis — Word count, keyword density, readability, keyword stuffing
  - Images & Media — Alt text, dimensions, lazy loading, WebP format
  - Social & Open Graph — og:title, og:image, Twitter cards, Facebook
  - Security & HTTPS — SSL, HSTS, CSP, mixed content, security headers
  - Mobile Responsiveness — Viewport, media queries, font sizes, tap targets

- **Three Report Formats:**
  - 📊 **JSON** — Machine-readable for CI/CD pipelines
  - 📄 **HTML** — Beautiful branded report for clients
  - 🤖 **AI Skill (SKILL.md)** — Agent-ready fix instructions in the format AI coding agents understand

- **Production-Grade Output:**
  - Every finding includes a specific, actionable fix
  - AI skill files include automated fix scripts (Next.js, Node.js, plain HTML)
  - Priority-ranked: Critical → Warning → Info

## Quick Start

```bash
# Run a full audit
npx seo-audit-pro audit https://yoursite.com

# Quick single-page check
npx seo-audit-pro quick https://yoursite.com

# Custom crawl depth and page limit
npx seo-audit-pro audit https://yoursite.com --depth 2 --max-pages 20

# Skip specific report formats
npx seo-audit-pro audit https://yoursite.com --skip-html --skip-json

# Custom output directory
npx seo-audit-pro audit https://yoursite.com --output ./my-reports
```

## Installation

```bash
# Global install (recommended)
npm install -g seo-audit-pro

# Or use directly with npx
npx seo-audit-pro audit https://example.com

# Or clone and run locally
git clone <repo>
cd seo-audit-pro
npm install
node index.js audit https://example.com
```

## Output

```
./reports/
├── seo-audit-report.json      # Machine-readable data
├── seo-audit-report.html      # Client-ready HTML report
└── SKILL.md                    # AI agent implementation skill
```

## Requirements

- Node.js 18+ installed on any machine (Windows, macOS, Linux)
- No database, no API keys, no cloud dependencies
- Works on any website — public or internal

## Use Cases

- **SEO Agencies** — Generate professional client reports with actionable fixes
- **Developers** — Integrate into CI/CD pipelines (run `seo-audit-pro audit` before deployments)
- **AI Workflows** — Feed the SKILL.md to any AI coding agent for automated fixes
- **Site Owners** — Get a clear, prioritized roadmap to first-page rankings

## License

Proprietary — See LICENSE file.

---

Built by **The Bharat Digital** — Premium Web Development & IT Solutions
